﻿namespace SieuThiMini
{
    partial class QuanLy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelThongTin = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.UC_ThongKe = new SieuThiMini.GUI.UserCThongKe();
            this.UC_Kho = new SieuThiMini.GUI.UCKho();
            this.UC_NCC = new SieuThiMini.GUI.UCNhaCungCap();
            this.UC_TaiKhoan = new SieuThiMini.GUI.UCTaiKhoan();
            this.UC_SPKM = new SieuThiMini.GUI.UserCSPKM();
            this.UC_NV = new SieuThiMini.UCNhanVien();
            this.UC_SP = new SieuThiMini.UCSP();
            this.UC_CTKM = new SieuThiMini.UCCTKM();
            this.panelThongTin.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelThongTin
            // 
            this.panelThongTin.Controls.Add(this.UC_ThongKe);
            this.panelThongTin.Controls.Add(this.UC_Kho);
            this.panelThongTin.Controls.Add(this.UC_NCC);
            this.panelThongTin.Controls.Add(this.UC_TaiKhoan);
            this.panelThongTin.Controls.Add(this.UC_SPKM);
            this.panelThongTin.Controls.Add(this.UC_NV);
            this.panelThongTin.Controls.Add(this.UC_SP);
            this.panelThongTin.Controls.Add(this.UC_CTKM);
            this.panelThongTin.Location = new System.Drawing.Point(410, 4);
            this.panelThongTin.Name = "panelThongTin";
            this.panelThongTin.Size = new System.Drawing.Size(819, 637);
            this.panelThongTin.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.button10);
            this.panel1.Controls.Add(this.button9);
            this.panel1.Controls.Add(this.button8);
            this.panel1.Controls.Add(this.button7);
            this.panel1.Controls.Add(this.button6);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(2, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(392, 637);
            this.panel1.TabIndex = 2;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(211, 836);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(139, 76);
            this.button10.TabIndex = 10;
            this.button10.Text = "Thoát";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(40, 836);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(139, 76);
            this.button9.TabIndex = 9;
            this.button9.Text = "Đăng xuất";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(40, 754);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(310, 76);
            this.button8.TabIndex = 8;
            this.button8.Text = "Thống kê";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(40, 672);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(310, 76);
            this.button7.TabIndex = 7;
            this.button7.Text = "Kho";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(40, 590);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(310, 76);
            this.button6.TabIndex = 6;
            this.button6.Text = "Nhà cung cấp";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(40, 508);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(310, 76);
            this.button5.TabIndex = 5;
            this.button5.Text = "Tài khoản";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(40, 426);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(310, 76);
            this.button4.TabIndex = 4;
            this.button4.Text = "Nhân viên";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(40, 344);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(310, 76);
            this.button3.TabIndex = 3;
            this.button3.Text = "Sản phẩm";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(40, 262);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(310, 76);
            this.button2.TabIndex = 2;
            this.button2.Text = "Chương trình khuyến mãi";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(40, 180);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(310, 76);
            this.button1.TabIndex = 1;
            this.button1.Text = "Sản phẩm khuyễn mãi";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(159, 114);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "label1";
            // 
            // UC_ThongKe
            // 
            this.UC_ThongKe.Location = new System.Drawing.Point(0, 3);
            this.UC_ThongKe.Name = "UC_ThongKe";
            this.UC_ThongKe.Size = new System.Drawing.Size(810, 630);
            this.UC_ThongKe.TabIndex = 7;
            // 
            // UC_Kho
            // 
            this.UC_Kho.Location = new System.Drawing.Point(0, 3);
            this.UC_Kho.Name = "UC_Kho";
            this.UC_Kho.Size = new System.Drawing.Size(810, 630);
            this.UC_Kho.TabIndex = 6;
            // 
            // UC_NCC
            // 
            this.UC_NCC.Location = new System.Drawing.Point(0, 3);
            this.UC_NCC.Name = "UC_NCC";
            this.UC_NCC.Size = new System.Drawing.Size(810, 630);
            this.UC_NCC.TabIndex = 5;
            // 
            // UC_TaiKhoan
            // 
            this.UC_TaiKhoan.Location = new System.Drawing.Point(3, 3);
            this.UC_TaiKhoan.Name = "UC_TaiKhoan";
            this.UC_TaiKhoan.Size = new System.Drawing.Size(810, 630);
            this.UC_TaiKhoan.TabIndex = 4;
            // 
            // UC_SPKM
            // 
            this.UC_SPKM.Location = new System.Drawing.Point(0, 0);
            this.UC_SPKM.Name = "UC_SPKM";
            this.UC_SPKM.Size = new System.Drawing.Size(810, 630);
            this.UC_SPKM.TabIndex = 3;
            // 
            // UC_NV
            // 
            this.UC_NV.Location = new System.Drawing.Point(5, 2);
            this.UC_NV.Name = "UC_NV";
            this.UC_NV.Size = new System.Drawing.Size(805, 614);
            this.UC_NV.TabIndex = 2;
            // 
            // UC_SP
            // 
            this.UC_SP.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.UC_SP.Location = new System.Drawing.Point(0, 0);
            this.UC_SP.Name = "UC_SP";
            this.UC_SP.Size = new System.Drawing.Size(810, 630);
            this.UC_SP.TabIndex = 1;
            // 
            // UC_CTKM
            // 
            this.UC_CTKM.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.UC_CTKM.Location = new System.Drawing.Point(0, 0);
            this.UC_CTKM.Name = "UC_CTKM";
            this.UC_CTKM.Size = new System.Drawing.Size(810, 630);
            this.UC_CTKM.TabIndex = 0;
            // 
            // QuanLy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::SieuThiMini.Properties.Resources.backgroundmain;
            this.ClientSize = new System.Drawing.Size(1282, 653);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panelThongTin);
            this.Name = "QuanLy";
            this.Text = "QuanLy";
            this.panelThongTin.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panelThongTin;
        private UCCTKM UC_CTKM;
        private UCSP UC_SP;
        private UCNhanVien UC_NV;
        private GUI.UserCSPKM UC_SPKM;
        private GUI.UserCThongKe UC_ThongKe;
        private GUI.UCKho UC_Kho;
        private GUI.UCNhaCungCap UC_NCC;
        private GUI.UCTaiKhoan UC_TaiKhoan;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
    }
}